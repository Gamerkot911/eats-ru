# $protocol
пишет протокол в данный момент.

### пример:
```js
$protocol // http or https
```
