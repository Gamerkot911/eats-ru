# $uppercase
Convert a string to uppercase.

### Parameters:
| Name | Type | Description | Optional |
| ---- | ---- | ------------| -------- |
| text | String | The text to convert to uppercase | false |

### Example:
  
```js
$uppercase[hello] // HELLO
```
