# $trim
Trims a text (remove unnecesary spaces [extras]).

### Parameters:
| Name     | Type      | Description            | Optional |
| -------- | --------- | ---------------------- | -------- |
| text     | String    | The text to trim.      | false    |

### Example:

```js
$trim[   Hello world hehe xd   ] // Hello world hehe xd

```
