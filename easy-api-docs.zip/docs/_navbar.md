<!-- _navbar.md -->

* [Home](/)
* [Package](https://npmjs.com/package/easy-api.ts)
* [Discord](https://discord.gg/fc6n37dCgY)
